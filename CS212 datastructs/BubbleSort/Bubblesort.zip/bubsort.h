// Nadine Dabby
// June 9, 2004
//
// Bubble Sort Header File
//
//This is the prototype of the bubble sort function. 
//It takes two parameters: an integer array  and a constant integer (the size of the array).
//It does not return a value.

#ifndef BUBSORT_H
#define BUBSORT_H

void bubbleSort(int [], const int); 

#endif