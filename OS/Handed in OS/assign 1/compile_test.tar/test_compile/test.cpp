int square_me( int x )
{
  return x * x;
}
