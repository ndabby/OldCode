#include <iostream>
#include "test.h"

using namespace std;

int main( void )
{
  cout << "We're calling a function titled square_me, defined in test.h" 
       << endl;
  cout << square_me( 12 ) << endl;
  return 0;
}
