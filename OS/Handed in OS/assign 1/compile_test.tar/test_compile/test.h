int square_me( int x );
